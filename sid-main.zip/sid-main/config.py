# Don't use quotes( " and ' )
#SCRIPT BY SASUKE
  
#Enter Your Bot Token here get it from @botfarher
BOT_TOKEN=("7489795692:AAFl-8d1S5Lf-WgH9skDbxFirj_xm6F4TOM")

  #Enter Your telegram username here without @
OWNER_USERNAME=("@Mr_sid_001")

  #Enter your admin id here Get it from @missRose_bot by typing /info
ADMIN_IDS=("1329951770")







  
